﻿
namespace SCM.RabbitMQClient.Common
{
    /// <summary>
    /// Log定位器.
    /// </summary>
    public class LogLocation
    {
        /// <summary>
        /// ILog实例。
        /// </summary>
        public static ILog Log { get; set; }
    }
}