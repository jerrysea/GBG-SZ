USE [InstinctHCACN]
GO

/****** Object:  Table [dbo].[Staging_Final_Decision]    Script Date: 2016/7/25 17:50:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
drop table [dbo].[Staging_Final_Decision]
CREATE TABLE [dbo].[Staging_Final_Decision](
	[Application_Number] [nvarchar](255) NULL,
	[Amount_Limit] [nvarchar](255) NULL,
	[Decision_Reason] [nvarchar](255) NULL,
	[Decision_Date] [nvarchar](255) NULL,
	[Surname] [nvarchar](255) NULL,
	[User_Field10] [nvarchar](255) NULL,
	[User_Field56] [nvarchar](2000) NULL,
	[User_Field57] [nvarchar](2000) NULL,
	[User_Field58] [nvarchar](2000) NULL,
	[User_Field59] [nvarchar](2000) NULL,
	[User_Field25] [nvarchar](2000) NULL,
	[User_Field26] [nvarchar](2000) NULL,
	[RowDelimiter] [nvarchar](50) NULL
) ON [PRIMARY]

GO


