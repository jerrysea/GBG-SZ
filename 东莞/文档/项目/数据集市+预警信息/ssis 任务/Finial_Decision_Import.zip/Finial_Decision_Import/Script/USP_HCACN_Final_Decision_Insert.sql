
ALTER PROCEDURE USP_HCACN_Final_Decision_Insert
	AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE A SET 
	A.User_Field10 = LEFT(B.User_Field10,50),
	A.Amount_Limit = CASE WHEN ISNUMERIC(B.Amount_Limit)=1 THEN CAST(REPLACE(B.Amount_Limit,',','') AS NUMERIC(19,2)) ELSE NULL END ,
	A.Decision = LEFT(B.Decision_Reason,10),
	A.Decision_Date = CASE WHEN ISDATE(SUBSTRING(B.Decision_Date,7,4) + '-' + SUBSTRING(B.Decision_Date,4,2) + '-' + SUBSTRING(B.Decision_Date,1,2) )=1 THEN CAST(SUBSTRING(B.Decision_Date,7,4) + '-' + SUBSTRING(B.Decision_Date,4,2) + '-' + SUBSTRING(B.Decision_Date,1,2) AS DATETIME) ELSE NULL END,
	A.User_Field26=LEFT(B.User_Field25,50),
	A.User_Field27=LEFT(B.User_Field26,50)
	FROM A_Application A(NOLOCK), Staging_Final_Decision B(NOLOCK)
	WHERE A.Application_Number= B.Application_Number

	UPDATE C SET 
	C.User_Field56= B.User_Field56,
	C.User_Field57= B.User_Field57,
	C.User_Field58= B.User_Field58,
	C.User_Field59= B.User_Field59
	FROM A_Application A(NOLOCK), Staging_Final_Decision B(NOLOCK),A_U2A C(NOLOCK)
	WHERE A.Application_Number= B.Application_Number AND A.AppKey = C.AppKey
	
	UPDATE C SET 
	C.Id_Number3= REPLACE(B.RowDelimiter,'|','')
	FROM A_Application A(NOLOCK), Staging_Final_Decision B(NOLOCK),A_Applicant C(NOLOCK)
	WHERE A.Application_Number= B.Application_Number AND A.AppKey = C.AppKey

	UPDATE C SET 
	C.Surname= B.Surname
	FROM A_Application A(NOLOCK), Staging_Final_Decision B(NOLOCK),A_User C(NOLOCK)
	WHERE A.Application_Number= B.Application_Number AND A.AppKey = C.AppKey
	
END
GO
